//
//  BookingDetailsViewController.swift
//  AirFinch_Swift
//
//  Created by Hitasoft on 28/10/20.
//  Copyright © 2020 BTMani. All rights reserved.
//

import UIKit
import Cosmos
import Razorpay
import ConnectyCube
import ConnectyCubeCalls
import PushKit
import JTMaterialTransition
import SwiftUI


class BookingDetailsViewController: UIViewController {
    
    @IBOutlet weak var nameHeight: NSLayoutConstraint!
    @IBOutlet weak var firstStackViewTop: NSLayoutConstraint!
    
    @IBOutlet weak var genderHeight: NSLayoutConstraint!
    
    @IBOutlet weak var illnessHeight: NSLayoutConstraint!
    
    @IBOutlet weak var TopStackView: UIStackView!
    @IBOutlet weak var firstStackView: UIStackView!
    @IBOutlet weak var lastStackViewheight: NSLayoutConstraint!
    @IBOutlet weak var genderStackView: UIStackView!
    @IBOutlet weak var StackViewBottom: NSLayoutConstraint!
    @IBOutlet weak var prescriptionButton: UIButton!
    @IBOutlet weak var chatButton: UIButton!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var totalTitleLabel: UILabel!
    @IBOutlet weak var siteLabel: UILabel!
    @IBOutlet weak var siteTitleLabel: UILabel!
    @IBOutlet weak var taxLabel: UILabel!
    @IBOutlet weak var taxTitleLabel: UILabel!
    @IBOutlet weak var wholeStackView: UIStackView!
    @IBOutlet weak var statusStackView: UIStackView!
    @IBOutlet weak var videoVisitButton: UIButton!
    @IBOutlet weak var payButton: UIButton!
    @IBOutlet weak var ratingCountLabel: UILabel!
    @IBOutlet weak var ratingView: CosmosView!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var specialityLabel: UILabel!
    @IBOutlet weak var doctorNameLabel: UILabel!
    @IBOutlet weak var doctorImageView: UIImageView!
    @IBOutlet weak var bookingDateTitleLabel: UILabel!
    @IBOutlet weak var bookingDateLabel: UILabel!
    @IBOutlet weak var bookingTimeLabel: UILabel!
    @IBOutlet weak var bookingTimeTitleLabel: UILabel!
    @IBOutlet weak var bookingReasonTitleLabel: UILabel!
    @IBOutlet weak var bookingReasonLabel: UILabel!
    @IBOutlet weak var priceTitleLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var policyTitleLabel: UILabel!
    @IBOutlet weak var policyLabel: UILabel!
    @IBOutlet weak var acceptButton: UIButton!
    @IBOutlet weak var declineButton: UIButton!
    @IBOutlet weak var videoButton: UIButton!
    @IBOutlet weak var prescriptionView: UIView!
    @IBOutlet weak var prescriptionSelectorView: UIView!
    @IBOutlet weak var handwrittingButton: UIButton!
    @IBOutlet weak var onlineButton: UIButton!
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var checkBoxView: VKCheckbox!
    @IBOutlet weak var checkbox: UIButton!
    @IBOutlet weak var checkBoxView1: VKCheckbox!
    @IBOutlet weak var checkbox1: UIButton!
    @IBOutlet weak var prescriptionTitleTextView: UILabel!
    @IBOutlet weak var paymentStatusLabel: UILabel!
    @IBOutlet weak var paymentTitleLabel: UILabel!
    @IBOutlet weak var detailsView: UIView!
    @IBOutlet weak var doctordetailsLbl: UILabel!
    @IBOutlet weak var patientdeailsLbl: UILabel!
    @IBOutlet weak var doctorNameLbl: UILabel!
    @IBOutlet weak var doctorNameView: UIView!
    @IBOutlet weak var doctorNameTittleLbl: UILabel!
    @IBOutlet weak var doctorEmailTittleLbl: UILabel!
    @IBOutlet weak var doctorEmailLbl: UILabel!
    @IBOutlet weak var doctorEmailView: UIView!
    @IBOutlet weak var doctorgenderTittleLbl: UILabel!
    @IBOutlet weak var doctorgenderLbl: UILabel!
    @IBOutlet weak var doctorgenderView: UIView!
    @IBOutlet weak var doctorQualificationTittleLbl: UILabel!
    @IBOutlet weak var doctorQualificationLbl: UILabel!
    @IBOutlet weak var doctorQualificationView: UIView!
    @IBOutlet weak var doctorMobileTittleLbl: UILabel!
    @IBOutlet weak var doctorMobileLbl: UILabel!
    @IBOutlet weak var doctorMobileView: UIView!
    @IBOutlet weak var patientNameTittleLbl: UILabel!
    @IBOutlet weak var patientNameView: UIView!
    @IBOutlet weak var patientNameLbl: UILabel!
    @IBOutlet weak var patientAgeTittleLbl: UILabel!
    @IBOutlet weak var patientAgeLbl: UILabel!
    @IBOutlet weak var patientAgeView: UIView!
    @IBOutlet weak var patientgenderTittleLbl: UILabel!
    @IBOutlet weak var patientgenderLbl: UILabel!
    @IBOutlet weak var patientgenderView: UIView!
    @IBOutlet weak var patientweightTittleLbl: UILabel!
    @IBOutlet weak var patientweightLbl: UILabel!
    @IBOutlet weak var patientweightView: UIView!
    @IBOutlet weak var patientillnessTittleLbl: UILabel!
    @IBOutlet weak var patientillnessLbl: UILabel!
    @IBOutlet weak var patientillnessView: UIView!
    @IBOutlet weak var secondStackView: UIStackView!    
    @IBOutlet weak var stauscheckStackView: UIStackView!
    @IBOutlet weak var statuscheckView: UIView!
    @IBOutlet weak var statusCheckTittleLbl: UILabel!
    @IBOutlet weak var statusCHeckLbl: UILabel!
    @IBOutlet weak var resudleStatckView: UIStackView!
    @IBOutlet weak var resudleTittleLbl: UILabel!
    @IBOutlet weak var resudleLbl: UILabel!
    
    @IBOutlet weak var bookingstatusStackView: UIStackView!
    @IBOutlet weak var bookingstatusLbl: UILabel!
    @IBOutlet weak var bookingstatusTittleLbl: UILabel!
    @IBOutlet weak var bookingstatusView: UIView!
    @IBOutlet weak var patientPhnStackView: UIStackView!
    
    @IBOutlet weak var patientPhnView: UIView!
    @IBOutlet weak var patientPhnTittleLbl: UILabel!
    
    @IBOutlet weak var patientPhnLbl: UILabel!
    
    @IBOutlet weak var RescheduleBtn: UIButton!
    
    @IBOutlet weak var RescheduleView: UIView!
    
    var client_id = ""
    var viewModel = BookingHistoryViewModel()
    var bookingResultModel: BookingHistoryResultModel?
    var type = ""
    var historyType = ""
    var booking_id = ""
    var user_id = ""
    var isForCall = false
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var isFromChat = false
    var isChecked = false
    var prescriptiontype = ""
    var completepage = ""
    var testing = "connect"
    var myNumber : NSNumber!
    private var session: CallSession?
    private var callUUID: UUID?
//    private var pushRegistry: PKPushRegistry!
    private var backgroundTask: UIBackgroundTaskIdentifier!
    
    //newwork
    var create_invoice = ""
    
//    var getbooking_status = ""
    var complete_status = ""
    
    //invoicedetails
    var lawyer_name = ""
    var client_name = ""
    var previously_paid = ""
    var pending_amount = ""
    var payment_type = ""
    var payingamount_type = ""
    var total_fee = ""
    var bank_details = ""
    var invoice_name = ""
    var taxamount = ""
    
    var total_value = ""
    var term_fee = ""
    var invoice_date = ""
    var paid_status = ""
    var currency_symbol = ""
    var currency_code = ""
    var invoice_id = ""
    var stripe_privatekey = ""
    var stripe_publickey = ""
    
    var lawyerlogin = ""
    var lawyerpassword = ""
    var lawyerconnecty_Id = ""
    var lawyeremail = ""
    var clientlogin = ""
    var clientpassword = ""
    var clientconnecty_Id = ""
    var clientemail = ""
    var somestring = ""

    var timer: Timer!
    var sec = 0
    var showtime = 0
    var confrimpage = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(indicatorView)
        Utility.shared.startAnimation(viewController: self)
        self.configUI()
        self.configCheckBox()
        if bookingResultModel?.status.lowercased() ?? "" == "pending"{
            self.resudleStatckView.isHidden = true
            self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updatetime), userInfo: nil, repeats: true)
        }
        if self.testing == "connect"{
            CallClient.initializeRTC()
            Profile.load()
        }

        // Do any additional setup after loading the view.
    }
    func loadData() {
        //        Utility.shared.startAnimation(viewController: self)
                self.viewModel.viewBookingDetails(user_id: (UserDefaultModule.shared.getLoginData().userId ?? ""), type: UserDefaultModule.shared.getLoginData().type, booking_id: self.booking_id, booking_schedule: "new", onSuccess: { (success) in            if self.viewModel.historyModel?.result.count ?? 0 > 0 {
                        self.bookingResultModel = self.viewModel.historyModel?.result.first
                        //connectycube
                        self.lawyerlogin = self.bookingResultModel?.connectycube_userlogin ?? ""
                        self.lawyerpassword = self.bookingResultModel?.connectycube_password ?? ""
                        self.lawyerconnecty_Id = self.bookingResultModel?.connectycube_userid ?? ""
                        self.lawyeremail = UserDefaultModule.shared.getLoginData().email ?? ""
                        
                        self.clientlogin = self.bookingResultModel?.ownuser_connectycube_userlogin ?? ""
                        print("clientlogin ===== \(self.clientlogin)")
                        self.clientpassword = self.bookingResultModel?.ownuser_connectycube_password ?? ""
                        self.clientconnecty_Id = self.bookingResultModel?.ownuser_connectycube_userid ?? ""
                        self.clientemail = UserDefaultModule.shared.getLoginData().email ?? ""
                    
                        if (UserDefaultModule.shared.getLoginData().type ?? "").lowercased() == "doctor"{
                            
                            UserDefaultModule.shared.setconnectyLogin(login: self.lawyerlogin, password: self.lawyerpassword, Id: self.lawyerconnecty_Id, email: self.lawyeremail)
                            
                            let user = User()
                            
                            let id = UserDefaultModule.shared.getconnectyLoginData().user_id
                            let convertint_Id = UInt(id)
                            
                            user.id = convertint_Id ?? 0
                            user.email = UserDefaultModule.shared.getconnectyLoginData().email
                            user.login = UserDefaultModule.shared.getconnectyLoginData().login
                            user.fullName = UserDefaultModule.shared.getLoginData().firstName ?? ""
                            user.password = UserDefaultModule.shared.getconnectyLoginData().password
                            
                            Profile.currentProfile = user
                            
                            if Profile.currentProfile != nil {

                                CallsApp.connect()
                            }
                            
                    
                        }else{
                            UserDefaultModule.shared.setconnectyLogin(login: self.clientlogin, password: self.clientpassword, Id: self.clientconnecty_Id, email: self.clientemail)
                            
                            let user = User()
                            
                            let id = UserDefaultModule.shared.getconnectyLoginData().user_id
                            let convertint_Id = UInt(id)
                            
                            user.id = convertint_Id ?? 0
                            user.email = UserDefaultModule.shared.getconnectyLoginData().email
                            user.login = UserDefaultModule.shared.getconnectyLoginData().login
                            user.fullName = UserDefaultModule.shared.getLoginData().firstName ?? ""
                            user.password = UserDefaultModule.shared.getconnectyLoginData().password
                            
                            Profile.currentProfile = user
                            print(Profile.currentProfile)
                            
                            if Profile.currentProfile != nil {

                                CallsApp.connect()
                            }
                            
                        }
                        

                        
                        //self.client_id = self.bookingResultModel?.userId ?? ""
                        self.client_id = self.bookingResultModel?.client_id ?? ""
                        
        //                self.getbooking_status = self.bookingResultModel?.getbooking_status ?? ""
        //                self.complete_status = self.bookingResultModel?.complete_status ?? ""
                        

                        self.loadUserData()
                    }
        //            Utility.shared.stopAnimation(viewController: self)
                }) { (failure) in
        //            Utility.shared.stopAnimation(viewController: self)
                }
            }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        NotificationCenter.default.addObserver(self, selector: #selector(self.barButtonAction(_:)), name: Notification.Name("BarButtonAction"), object: self)
    }
    @objc func barButtonAction(_ notification: Notification) {
        print(notification)
        if !self.prescriptionView.isHidden{
            self.prescriptionView.isHidden = true
        }else{
        if let isLeft = notification.userInfo?["isLeft"] as? Int {
            print(isLeft)
            if isLeft == 0 {
                if isForCall {
                    if UserDefaultModule.shared.getLoginData().type == "user"{
                        let pageObj = UserTabbarController()
                        self.appDelegate.setInitialViewController(initialView: pageObj)
                    }else if UserDefaultModule.shared.getLoginData().type == "digitalclinic"{
                        let pageObj = DCTabbarViewController()
                        self.appDelegate.setInitialViewController(initialView: pageObj)
                    }else{
                        let pageObj = DoctorTabViewController()
                        self.appDelegate.setInitialViewController(initialView: pageObj)

                    }
                }
                else {
                    self.navigationController?.popViewController(animated: true)
                }
            }
            else if isLeft == 1{
                
            }
            else if isLeft == 2{
                
            }
            }
        }
    }
    @objc func updatetime() {
        var timestamp = NSDate().timeIntervalSince1970
        if Int(timestamp)  >= self.showtime && (bookingResultModel?.status.lowercased() ?? "") == "pending"{
            self.declineButton.isHidden = false
//            self.loadUserData()
            print("check4")
            self.timer?.invalidate()
            self.timer = nil
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
//        self.navigationController?.setNavigationBarHidden(true, animated: true)
        NotificationCenter.default.removeObserver(self, name: Notification.Name("BarButtonAction"), object: self)
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    func configUI() {
        self.declineButton.isHidden = true
        if UserDefaultModule.shared.getLoginData().type == "digitalclinic"{
           // self.StackViewBottom.constant = 270
        }else if UserDefaultModule.shared.getLoginData().type == "doctor"{
            self.StackViewBottom.constant = 250
        }
        else{
            self.StackViewBottom.constant = 15
            self.detailsView.isHidden = true
        }
        self.RescheduleView.isHidden = true
        self.navigationController?.NavigationBarWithBackButtonAndTitle(title: Utility().language().value(forKey: "details") as? String ?? "", fColor: "White", fontName: fontRegular18, imageName: "left_arrow", isLeft: true, vc: self, transparantView: false)
        self.prescriptionSelectorView.layer.cornerRadius = 10
        self.doneButton.layer.cornerRadius = 5
        self.prescriptionView.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.navigationController?.updateTransparantBackGround(false, vc: self)
        self.videoButton.cornerViewRadius()
        self.prescriptionView.isHidden = true
        self.handwrittingButton.config(color: UIColor(named: "TitleColor"), font: fontsemi16, align: .center, title: "handwriting")
        self.onlineButton.config(color: UIColor(named: "TitleColor"), font: fontsemi16, align: .center, title: "online_or_offline")
        self.doneButton.config(color: UIColor(named: "white"), font: fontsemi16, align: .center, title: "done")
        self.prescriptionTitleTextView.config(color: UIColor(named: "TitleColor"), font: fontsemi16, align: .center, text: "prescription_heading")
        self.doctorImageView.contentMode = .scaleAspectFill
        self.doctorImageView.cornerViewRadius()
        self.doctorNameLabel.config(color: UIColor(named: "TitleColor"), font: fontsemi16, align: .left, text: "")
        self.specialityLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "")
        self.locationLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "")
        self.ratingCountLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "")
        self.bookingDateTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "booking_date")
        self.bookingDateLabel.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.bookingstatusTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "booking_status")
        self.bookingstatusLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.bookingReasonTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "booking_reason")
        self.bookingReasonLabel.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.bookingTimeTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "booking_time")
        self.bookingTimeLabel.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.policyTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "cancellation")
        self.policyLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "")
        self.acceptButton.config(color: UIColor(named: "White"), font: fontRegular16, align: .center, title: "accept")
        self.RescheduleBtn.config(color: UIColor(named: "White"), font: fontRegular16, align: .center, title: "reschedule")
        self.chatButton.config(color: UIColor(named: "White"), font: fontRegular16, align: .center, title: "chat")
        self.prescriptionButton.config(color: UIColor(named: "AppColor"), font: fontRegular16, align: .right, title: "prescription")
        self.chatButton.cornerMiniumRadius()
        self.chatButton.backgroundColor = UIColor(named: "AppColor")
        self.acceptButton.cornerMiniumRadius()
        self.acceptButton.backgroundColor = UIColor(named: "AppColor")
        self.declineButton.config(color: UIColor(named: "AppColor"), font: fontRegular16, align: .center, title: "decline")
        self.declineButton.cornerMiniumRadius()
        self.declineButton.backgroundColor = UIColor(named: "BorderColor")
        self.payButton.config(color: UIColor(named: "White"), font: fontRegular16, align: .center, title: "pay")
        self.payButton.cornerMiniumRadius()
        self.payButton.backgroundColor = UIColor(named: "AppColor")
        self.payButton.isHidden = true
        self.videoVisitButton.config(color: UIColor(named: "White"), font: fontRegular16, align: .center, title: "video_visit")
        self.videoVisitButton.cornerMiniumRadius()
        self.videoVisitButton.backgroundColor = UIColor(named: "AppColor")
        self.videoVisitButton.isHidden = true
        self.videoButton.cornerViewRadius()
        self.priceTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "fees")
        self.priceLabel.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.siteTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "sitecharges")
        self.siteLabel.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.taxTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "tax")
        self.taxLabel.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.totalTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "total")
        self.totalLabel.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.paymentTitleLabel.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "payment")
        self.paymentStatusLabel.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.resudleTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "resudle_time")
        self.resudleLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
       // if bookingResultModel?.status == "accepted"{
            self.statusCheckTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "status")
      //  }

        if UserDefaultModule.shared.getLoginData().type == "digitalclinic"{
                self.TopStackView.isHidden = false
                self.doctorNameTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "name")
                self.doctorNameLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
                self.doctorEmailTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "email")
                self.doctorEmailLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
                self.doctorgenderTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "patient_gender")
                self.doctorgenderLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
                self.doctorQualificationTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "qualification")
                self.doctorQualificationLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
                self.doctorMobileTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "mobile_no")
                self.doctorMobileLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
                self.doctordetailsLbl.config(color: UIColor(named: "TitleColor"), font: fontsemi16, align: .left, text: "doctor_details")
                self.patientdeailsLbl.config(color: UIColor(named: "TitleColor"), font: fontsemi16, align: .left, text: "patient_details")
            self.patientPhnTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "patient_phonebumber")
            self.patientPhnLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        }else if UserDefaultModule.shared.getLoginData().type == "doctor" {
            self.TopStackView.isHidden = false
            self.doctorNameTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "name")
            self.doctorNameLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
            self.doctorEmailTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "email")
            self.doctorEmailLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
            self.doctorMobileTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "mobile_no")
            self.doctorMobileLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
            self.doctorgenderTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "host_address")
            self.doctorgenderLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
            self.genderStackView.isHidden = true
            self.doctordetailsLbl.config(color: UIColor(named: "TitleColor"), font: fontsemi16, align: .left, text: "dc_details")
            self.patientdeailsLbl.config(color: UIColor(named: "TitleColor"), font: fontsemi16, align: .left, text: "patient_details")
            self.statusCHeckLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        }
        self.patientNameTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "name")
        self.patientNameLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text:"")
        self.patientAgeTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "age")
        self.patientAgeLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text:"")
        self.patientgenderTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "patient_gender")
        self.patientgenderLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.patientweightTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "weight")
        self.patientweightLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text: "")
        self.patientillnessTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "issue_complaint")
        self.patientillnessLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .left, text: "")
     
        self.loadUserData()
        self.loadData()
    }
    func loadUserData() {
        self.wholeStackView.isHidden = true
        if self.bookingResultModel != nil {
            Utility.shared.stopAnimation(viewController: self)
            if (UserDefaultModule.shared.getLoginData().type ?? "").lowercased() != "doctor" {
                if (bookingResultModel?.slotBookingtype.lowercased() ?? "") == "videovisit" {
                    self.videoButton.isHidden = false
                }
                else {
                    self.videoButton.isHidden = true
                }
            }
            else {
                self.videoButton.isHidden = true
            }
            
            self.wholeStackView.isHidden = false
            if self.bookingResultModel?.reschedule_time != "" {
                self.resudleStatckView.isHidden = false
            }
            if (UserDefaultModule.shared.getLoginData().type ?? "") == "user" {
                self.doctorNameLabel.text = "Dr.\(bookingResultModel?.userName ?? "")"
            } else if (UserDefaultModule.shared.getLoginData().type ?? "") == "digitalclinic"{
                self.doctorNameLabel.text = "Dr.\(bookingResultModel?.userName ?? "")"
            }
            else {
                self.doctorNameLabel.text = bookingResultModel?.userName ?? ""
            }
            
            self.specialityLabel.text = bookingResultModel?.speciality ?? ""
            if UserDefaultModule.shared.getLoginData().type == "doctor"{
                self.locationLabel.text = bookingResultModel?.location ?? ""
            }else{
                self.locationLabel.text = bookingResultModel?.doctor_location ?? ""
            }
            self.payButton.setTitle("\(getLanguage["pay"] ?? "") \(self.bookingResultModel?.currency ?? "")\(self.bookingResultModel?.grandTotal ?? "0")", for: .normal)

            self.doctorImageView.sd_setImage(with: URL(string: (bookingResultModel?.userImage ?? "")), placeholderImage: #imageLiteral(resourceName: "doctorProfile"), completed: nil)
            self.doctorImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.profileAct)))
            let bookingDate = Date(timeIntervalSince1970: Double(self.bookingResultModel?.bookingDate ?? 0))
            self.bookingDateLabel.text = (Utility.shared.convertTimeStampWithDateFormat(timeStamp: "\((self.bookingResultModel?.bookingDate ?? 0))", dateFormat: "MMM dd,yyyy"))
            self.bookingTimeLabel.text = bookingResultModel?.time ?? ""
            self.bookingstatusLbl.text = bookingResultModel?.status ?? ""
            self.resudleLbl.text = bookingResultModel?.reschedule_time ?? ""
            let reason: [String] = bookingResultModel?.bookingReason.map({$0.name}) ?? [String]()
            self.bookingReasonLabel.text = reason.joined(separator: ", ")
            self.priceLabel.text = "\(bookingResultModel?.currency ?? "")\(bookingResultModel?.consultFees ?? "0")"
            self.siteLabel.text = "\(bookingResultModel?.currency ?? "")\(bookingResultModel?.sitefees ?? "")"
            self.taxLabel.text = "\(bookingResultModel?.currency ?? "")\(bookingResultModel?.tax ?? "")"
            self.totalLabel.text = "\(bookingResultModel?.currency ?? "")\(bookingResultModel?.grandTotal ?? "0")"
            self.policyLabel.text = bookingResultModel?.content
            self.paymentStatusLabel.text = (getLanguage[(bookingResultModel?.orderstatus ?? "")] ?? (bookingResultModel?.orderstatus ?? "")).capitalized
            self.payButton.isHidden = true
            
            // DC Details
          if UserDefaultModule.shared.getLoginData().type == "digitalclinic"{
                  self.doctorNameLbl.text = "Dr.\(bookingResultModel?.doctorname ?? "")"
                  self.doctorgenderLbl.text = "\(bookingResultModel?.doctorgender ?? "")"
                  self.doctorEmailLbl.text = "\(bookingResultModel?.doctoremail ?? "")"
                  self.doctorMobileLbl.text = "\(bookingResultModel?.doctormobilenumber ?? "")"
                  self.doctorQualificationLbl.text = "\(bookingResultModel?.doctorqualification ?? "")"
                  
                  self.patientNameLbl.text = "\(bookingResultModel?.patientname ?? "")"
                  self.patientweightLbl.text = "\(bookingResultModel?.patientweight ?? "")"
                  self.patientillnessLbl.text = "\(bookingResultModel?.patientillness ?? "")"
                  self.patientAgeLbl.text = "\(bookingResultModel?.patientage ?? "")"
                  self.patientgenderLbl.text = "\(bookingResultModel?.patientgender ?? "")"
           //       self.patientPhnLbl.text = "\(bookingResultModel?.patient_phonenumber ?? "")"
              print("Lines:\(self.bookingResultModel?.patientillness.count)")
              if self.bookingResultModel?.patientillness.count ?? 0 >= 100{
                  self.StackViewBottom.constant = 610
              }
              else if self.bookingResultModel?.patientillness.count ?? 0 >= 50{
                  self.StackViewBottom.constant = 470
              }else{
                  self.StackViewBottom.constant = 300
              }
                 
                  self.statuscheckView.isHidden = true
                  self.statusCHeckLbl.isHidden = true
                  self.statusCheckTittleLbl.isHidden = true
              
            }
            else if UserDefaultModule.shared.getLoginData().type == "doctor"{
                self.patientPhnStackView.isHidden = true
                if bookingResultModel?.status == "accepted"{
                    self.statusCHeckLbl.text = "\(bookingResultModel?.status ?? "")"
                }else{
                    self.statuscheckView.isHidden = true
                    self.statusCHeckLbl.isHidden = true
                    self.statusCheckTittleLbl.isHidden = true
                }
                if "\(bookingResultModel?.dcname ?? "")" != "" {
                    self.firstStackView.isHidden = false
                    self.firstStackViewTop.constant = 10
                    self.StackViewBottom.constant = 270
                    self.nameHeight.constant = 45
                    self.genderHeight.constant = 45
                    self.patientgenderLbl.isHidden = false
                    self.patientgenderView.isHidden = false
                    self.patientgenderTittleLbl.isHidden = false
                    self.patientillnessView.isHidden = false
                    self.patientillnessLbl.isHidden = false
                    self.patientillnessTittleLbl.isHidden = false
                    self.doctordetailsLbl.isHidden = false
                    self.patientweightLbl.isHidden = false
                    self.patientweightView.isHidden = false
                    self.patientweightTittleLbl.isHidden = false
                    self.doctorNameLbl.text = "\(bookingResultModel?.dcname ?? "")"
                    self.doctorEmailLbl.text = "\(bookingResultModel?.dcemail ?? "")"
                    self.doctorMobileLbl.text = "\(bookingResultModel?.dcmobilenumber ?? "")"
                    self.doctorgenderLbl.text = "\(bookingResultModel?.dcaddress ?? "")"
                
                    self.patientweightLbl.text = "\(bookingResultModel?.patientweight ?? "")"
                    self.patientillnessLbl.text = "\(bookingResultModel?.patientillness ?? "")"
                    self.patientgenderLbl.text = "\(bookingResultModel?.patientgender ?? "")"
                    self.patientNameTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "name")
                    self.patientNameLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text:"")
                    self.patientAgeTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "age")
                    self.patientAgeLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text:"")
                    self.patientNameLbl.text = "\(bookingResultModel?.patientname ?? "")"
                    self.patientAgeLbl.text = "\(bookingResultModel?.patientage ?? "")"
                }else{
                    self.patientNameTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "age")
                    self.patientNameLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text:"")
                    self.patientAgeTittleLbl.config(color: UIColor(named: "SubTitleColor"), font: regular14, align: .left, text: "weight")
                    self.patientAgeLbl.config(color: UIColor(named: "TitleColor"), font: regular14, align: .right, text:"")
                    self.patientAgeLbl.text = "\(bookingResultModel?.patientweight ?? "")"
                    self.patientNameLbl.text = "\(bookingResultModel?.patientage ?? "")"
                    self.patientgenderLbl.isHidden = true
                    self.patientgenderView.isHidden = true
                    self.patientgenderTittleLbl.isHidden = true
                    self.patientillnessView.isHidden = true
                    self.patientillnessLbl.isHidden = true
                    self.patientillnessTittleLbl.isHidden = true
                    self.patientweightLbl.isHidden = true
                    self.patientweightView.isHidden = true
                    self.patientweightTittleLbl.isHidden = true
                    self.firstStackViewTop.constant = -250
                    self.StackViewBottom.constant = -200
                    self.doctordetailsLbl.isHidden = true
                    self.firstStackView.isHidden = true
                }
            }
            let timeZone = TimeZone(identifier: (bookingResultModel?.timezone ?? "0")) ?? TimeZone.current
            let currentDate = self.changeToSystemTimeZone(Date(), from: TimeZone.current, to: timeZone)
            let calendar = Calendar.current
//            calendar.timeZone = timeZone

            if type.lowercased() == "doctor" {
                self.declineButton.config(color: UIColor(named: "TitleColor"), font: regular14, align: .center, title: "decline")
            }
            else {
                self.declineButton.config(color: UIColor(named: "TitleColor"), font: regular14, align: .center, title: "cancel")
            }
            if (bookingResultModel?.type ?? "") == "current" {
                self.acceptButton.isHidden = true
                if bookingResultModel?.status == "pending"{
                    self.declineButton.isHidden = true
                    self.showtime = (bookingResultModel?.createdDate ?? 0)+900
                }else{
                    self.declineButton.isHidden = false
                }
                if (bookingResultModel?.status.lowercased() ?? "") == "accepted" {
                    if (bookingResultModel?.paytoken ?? "") == "" && bookingResultModel?.bookingType.lowercased() == "request" {
                        self.declineButton.isHidden = false
                        self.RescheduleBtn.isHidden = true
                        self.videoVisitButton.isHidden = true
                        if type.lowercased() != "doctor" {
                            self.payButton.isHidden = false
                        }
                        else {
                            self.declineButton.isHidden = true
                        }
                    }
                    else {
                        
                        if (bookingResultModel?.slotBookingtype.lowercased() ?? "") == "videovisit" {
                            self.RescheduleBtn.isHidden = true
                            self.videoVisitButton.alpha = 0.5
                 //           self.videoVisitButton.isHidden = false
                            let toArray = (bookingResultModel?.time ?? "").components(separatedBy: ":")
                            if (toArray.count) > 1 {
                                var mins = (Int(toArray.last ?? "0") ?? 0)
                                var hours = (Int(toArray.first ?? "0") ?? 0)

                                if mins < 5 {
                                    mins = 60-mins
                                    print("MINS:\(mins)")
                                }
                                else {
                                    mins = mins-5
                                    print("MINS:\(mins)")
                                }

                                if mins == 60 {
                                    mins = 55
                                    print("MINS:\(mins)")
                                    if hours == 0 {
                                        hours = 23
                                        print("Hours:\(hours)")
                                    }
                                    else {
                                        hours = hours-1
                                        print("Hours:\(hours)")
                                    }
                                }
                                
                                if let toDate = calendar.date(bySettingHour: hours, minute: mins, second: 0, of: bookingDate) {
                                    if currentDate >= toDate {
                                        print("TODATE:\(toDate)")
                                        print("CURRENTDATE:\(currentDate)")
                                        self.videoVisitButton.alpha = 1
                                        self.videoVisitButton.isHidden = false
                                    }
                                }
                            }
                        }
                        self.declineButton.isHidden = false
                    }
                    if type.lowercased() != "doctor"{
                        if bookingResultModel?.bookingType.lowercased() == "request" {
                            self.declineButton.isHidden = true
                        }
                        else {
                            self.declineButton.isHidden = false
                        }
                    }else {
                        if bookingResultModel?.bookingType.lowercased() == "request" {
                            self.declineButton.isHidden = true
                        }
                        else {
                            self.declineButton.config(color: UIColor(named: "TitleColor"), font: regular14, align: .center, title: "cancel")
                            self.declineButton.isHidden = false
                        }
                    }
                }
                else if (bookingResultModel?.status.lowercased() ?? "") == "cancelled" || (bookingResultModel?.status.lowercased() ?? "") == "refunded"{
                    self.declineButton.isHidden = true
                    self.videoVisitButton.isHidden = true
                    self.payButton.isHidden = true
                }
                else if (bookingResultModel?.status.lowercased() ?? "") == "declined" {
                    self.videoVisitButton.isHidden = true
                    self.payButton.isHidden = true
                    self.declineButton.isHidden = true
                }
                else if (bookingResultModel?.status.lowercased() ?? "") == "pending"{
                    if UserDefaultModule.shared.getLoginData().type == "doctor"{
                        self.RescheduleView.isHidden = false
                        self.acceptButton.isHidden = false
                        self.declineButton.isHidden = false
                    }else{
                        self.RescheduleView.isHidden = true
                    }
                }
                else if (bookingResultModel?.status.lowercased() ?? "") == "rescheduled"{
                    if UserDefaultModule.shared.getLoginData().type == "doctor"{
                        self.acceptButton.isHidden = true
                        self.declineButton.isHidden = true
                    }else{
                        self.confrimpage = "1"
                        self.acceptButton.config(color: UIColor(named: "White"), font: fontRegular16, align: .center, title: "confrim")
                        self.declineButton.config(color: UIColor(named: "White"), font: fontRegular16, align: .center, title: "cancel")
                        self.declineButton.isHidden = false
                        self.acceptButton.isHidden = false
                    }
                }
                else  {
                    self.RescheduleView.isHidden = true
                    self.payButton.isHidden = true
                    self.videoVisitButton.isHidden = true
                    if type.lowercased() != "doctor"{
                        self.declineButton.config(color: UIColor(named: "TitleColor"), font: regular14, align: .center, title: "cancel")
                        self.declineButton.isHidden = false
                    }
                    else {
                        self.acceptButton.isHidden = false
                        self.declineButton.isHidden = false
                    }
                }
            }
            else {
                self.acceptButton.isHidden = true
                self.declineButton.isHidden = true
            }
            // Check if current date in reached check in date
            let toArray = (bookingResultModel?.time ?? "").components(separatedBy: ":")
            if let toDate = calendar.date(bySettingHour: Int(toArray.first ?? "0") ?? 0, minute: Int(toArray.last ?? "0") ?? 0, second: 0, of: bookingDate) {
                print("Current Date \(currentDate)")
                print("toDate Date \(toDate)")
                if currentDate >= toDate {
                    self.payButton.isHidden = true
                    self.acceptButton.isHidden = true
                    self.declineButton.isHidden = true
                    self.chatButton.isHidden = false
                }
            }
            self.chatButton.isHidden = false
            self.prescriptionButton.isHidden = true
            if (bookingResultModel?.status.lowercased() ?? "") == "accepted" || (bookingResultModel?.status.lowercased() ?? "") == "completed" || (bookingResultModel?.status.lowercased() ?? "") == "paid"{
                if (bookingResultModel?.paytoken ?? "") == "" && bookingResultModel?.bookingType.lowercased() == "request" {
                    self.prescriptionButton.isHidden = true
                }
                else {
                    let toArray = (bookingResultModel?.time ?? "").components(separatedBy: ":")
                    var hours = (Int(toArray.first ?? "0") ?? 0)
                    var mins = (Int(toArray.last ?? "0") ?? 0)
                    if mins < 5 {
                        mins = 60-mins
                    }
                    else {
                        mins = mins-5
                    }
                    if mins == 60 {
                        mins = 55
                        if hours == 0 {
                            hours = 23
                        }
                        else {
                            hours = hours-1
                        }
                    }
                    if let toDate = calendar.date(bySettingHour: hours, minute: mins, second: 0, of: bookingDate) {
                        if currentDate >= toDate {
                            self.prescriptionButton.isHidden = false
                            self.acceptButton.isHidden = false
                            self.completepage = "1"
                            self.acceptButton.config(color: UIColor(named: "White"), font: fontRegular16, align: .center, title: "completed")
                        }
                    }
                }
            }
        }
        else {
            self.wholeStackView.isHidden = true
        }
    }
    func changeToSystemTimeZone(_ date: Date, from: TimeZone, to: TimeZone = TimeZone.current) -> Date {
        let sourceOffset = from.secondsFromGMT(for: date)
        let destinationOffset = to.secondsFromGMT(for: date)
        let timeInterval = TimeInterval(destinationOffset - sourceOffset)
        return Date(timeInterval: timeInterval, since: date)
    }
    @IBAction func RescheduleBtnAct(_ sender: Any) {
        let pageObj = BookingCalendarViewController()
        pageObj.type = "request"
        pageObj.booking_type = "videovisit"
        pageObj.redoctorID = self.bookingResultModel?.doctorId ?? ""
        pageObj.sendType = "redoctor"
        pageObj.res = "1"
        pageObj.bookingID = self.bookingResultModel?.bookingId ?? ""
        pageObj.resechudle_date = self.bookingResultModel?.bookingDate ?? 0
        self.navigationController?.pushViewController(pageObj, animated: true)
       
    }
    @objc func profileAct() {
        if (UserDefaultModule.shared.getLoginData().type) != "doctor" {
            let pageObj = DoctorDetailsViewController()
            pageObj.doctorID = (self.bookingResultModel?.doctorId ?? "")
            pageObj.type = (self.bookingResultModel?.speciality ?? "")
            self.navigationController?.pushViewController(pageObj, animated: true)
        }
    }
    @objc func videoCall(){
        
    }
    @objc func audioCall(){
        
    }
    func configCheckBox(){
        self.checkBoxView.line = .thin
        self.checkBoxView1.line = .thin
        self.checkBoxView.bgColorSelected  = AppRed
        self.checkBoxView1.bgColorSelected = AppRed
        self.checkBoxView.bgColor          = .white
        self.checkBoxView1.bgColor         = .white
        self.checkBoxView.color            = .white
        self.checkBoxView1.color           = .white
        self.checkBoxView.borderWidth      = 1.5
        self.checkBoxView.cornerRadius     = 2
        self.checkBoxView1.borderWidth      = 1.5
        self.checkBoxView1.cornerRadius     = 2
        self.checkBoxView.borderColor      = AppRed
        self.checkBoxView1.borderColor      = AppRed
        checkBoxView.checkboxValueChangedBlock = {
            isOn in
            if isOn == true{
                self.checkBoxView1.setOn(false, animated: true)
                self.prescriptiontype = "handwritting"
            }else{
                self.prescriptiontype = ""
            }
            print("Custom checkbox is \(isOn ? "ON" : "OFF")")
        }
        checkBoxView1.checkboxValueChangedBlock = {
            isOn in
            if isOn == true{
                self.checkBoxView.setOn(false, animated: true)
                self.prescriptiontype = "online"
            }else{
                self.prescriptiontype = ""
            }
            print("Custom checkbox1 is \(isOn ? "ON" : "OFF")")
        }
    }
    @IBAction func chatButtonAct(_ sender: UIButton) {
        if isFromChat {
            self.navigationController?.popViewController(animated: true)
        }
        else {
            let pageObj = ChatViewController()
            pageObj.isFromBooking = true
            pageObj.id = (self.bookingResultModel?.bookingId ?? "")
            pageObj.userName = (self.bookingResultModel?.userName ?? "")
            pageObj.receiverImage = (self.bookingResultModel?.userImage ?? "")
            self.navigationController?.pushViewController(pageObj, animated: true)
        }
    }
    @IBAction func doneButtonAct(_ sender: UIButton) {
        if self.prescriptiontype == "online"{
            let pageObj = PrescriptionViewController()
            pageObj.booking_id = self.bookingResultModel?.bookingId ?? ""
            self.navigationController?.pushViewController(pageObj, animated: true)
            self.prescriptionView.isHidden = true
        }else if self.prescriptiontype == "handwritting"{
            let pageObj = PrescriptionUploadViewController()
            pageObj.bookingID = self.bookingResultModel?.bookingId ?? ""
            self.navigationController?.pushViewController(pageObj, animated: true)
            self.prescriptionView.isHidden = true
        }else{
            self.prescriptionView.isHidden = true
        }
    }
    @IBAction func handwrittingButtonAct(_ sender: UIButton) {
        if !checkBoxView.isOn{
        self.checkBoxView.setOn(true, animated: true)
        self.checkBoxView1.setOn(false, animated: true)
        self.prescriptiontype = "handwritting"
        }else{
            self.checkBoxView.setOn(false, animated: true)
            self.prescriptiontype = ""
        }
    }
    @IBAction func onlineButtonAct(_ sender: UIButton) {
        if !checkBoxView1.isOn{
        self.checkBoxView.setOn(false, animated: true)
        self.checkBoxView1.setOn(true, animated: true)
        self.prescriptiontype = "online"
    }else{
        self.checkBoxView.setOn(false, animated: true)
        self.prescriptiontype = ""
    }
    }
    @IBAction func acceptButtonAct(_ sender: UIButton) {
        if self.completepage == "1"{
            let pageObj = compleReviewViewController()
            pageObj.booking_id = self.bookingResultModel?.bookingId ?? ""
            pageObj.status = self.bookingResultModel?.status ?? ""
            pageObj.modalPresentationStyle = .overCurrentContext
            self.present(pageObj, animated: true)
        }else{
            if UserDefaultModule.shared.getLoginData().type != "doctor" {
                Utility.shared.startAnimation(viewController: self)
                self.viewModel.reschudlebooking(user_id: (UserDefaultModule.shared.getLoginData().userId ?? ""), type: "reschedule", booking_id: (self.bookingResultModel?.bookingId ?? ""), status: "accepted", onSuccess: { (success) in
                    Utility.shared.stopAnimation(viewController: self)
                    let alert = UIAlertController(title: nil, message: getLanguage[(self.viewModel.actionModel?.message ?? "")] ?? (self.viewModel.actionModel?.message ?? ""), preferredStyle: .alert)
                    if success {
                        alert.message = getLanguage[(self.viewModel.actionModel?.message ?? "")] ?? (self.viewModel.actionModel?.message ?? "")
                    }
                    alert.addAction(UIAlertAction(title: getLanguage["OK"] ?? "", style: .cancel, handler: { (UIAlertAction) in
                        if success {
                            self.bookingResultModel?.status = "accepted"
                            self.loadUserData()
                        }
                    }))
                    self.present(alert, animated: true, completion: nil)
                }) { (failure) in
                    Utility.shared.stopAnimation(viewController: self)
                }
           /*
                self.viewModel.CancelBooking(user_id: (UserDefaultModule.shared.getLoginData().userId ?? ""), type: self.type, booking_id: (self.bookingResultModel?.bookingId ?? ""), status: "confrim", onSuccess: { (success) in
                    Utility.shared.stopAnimation(viewController: self)
                    let alert = UIAlertController(title: nil, message: getLanguage[(self.viewModel.actionModel?.message ?? "")] ?? (self.viewModel.actionModel?.message ?? ""), preferredStyle: .alert)
                    if success {
                        alert.message = getLanguage[(self.viewModel.actionModel?.message ?? "")] ?? (self.viewModel.actionModel?.message ?? "")
                    }
                    alert.addAction(UIAlertAction(title: getLanguage["OK"] ?? "", style: .cancel, handler: { (UIAlertAction) in
                        if success {
                            self.bookingResultModel?.status = "accepted"
                            self.loadUserData()
                        }
                    }))
                    self.present(alert, animated: true, completion: nil)
                }) { (failure) in
                    Utility.shared.stopAnimation(viewController: self)
                }
                */
            }else{
                Utility.shared.startAnimation(viewController: self)
                self.viewModel.CancelBooking(user_id: (UserDefaultModule.shared.getLoginData().userId ?? ""), type: self.type, booking_id: (self.bookingResultModel?.bookingId ?? ""), status: "accepted", onSuccess: { (success) in
                    Utility.shared.stopAnimation(viewController: self)
                    let alert = UIAlertController(title: nil, message: getLanguage[(self.viewModel.actionModel?.message ?? "")] ?? (self.viewModel.actionModel?.message ?? ""), preferredStyle: .alert)
                    if success {
                        alert.message = getLanguage[(self.viewModel.actionModel?.message ?? "")] ?? (self.viewModel.actionModel?.message ?? "")
                    }
                    alert.addAction(UIAlertAction(title: getLanguage["OK"] ?? "", style: .cancel, handler: { (UIAlertAction) in
                        if success {
                            self.bookingResultModel?.status = "accepted"
                            self.loadUserData()
                        }
                    }))
                    self.present(alert, animated: true, completion: nil)
                }) { (failure) in
                    Utility.shared.stopAnimation(viewController: self)
                }
            }
        }
    }
    
    @IBAction func payButtonAct(_ sender: UIButton) {
        let pageObj = PaymentViewController()
        let doctorDetails = DoctorResultModel(averageRating: (self.bookingResultModel?.rating ?? ""), bookingType: (self.bookingResultModel?.bookingType ?? ""), doctorId: (self.bookingResultModel?.doctorId ?? ""), doctorImage: (self.bookingResultModel?.userImage ?? ""), consultFees: (self.bookingResultModel?.consultFees ?? ""), slotBookingtype: (self.bookingResultModel?.slotBookingtype ?? ""))
        pageObj.doctorData = doctorDetails
        pageObj.bookingSlotModel = BookingSlotResultModel(consultFees: (self.bookingResultModel?.consultFees ?? ""), currency: (self.bookingResultModel?.currency ?? ""), grandTotal: (self.bookingResultModel?.grandTotal ?? ""), sitefees: (self.bookingResultModel?.sitefees ?? ""), tax: (self.bookingResultModel?.tax ?? ""), currencycode: (self.bookingResultModel?.tax ?? ""), price: (self.bookingResultModel?.price ?? ""), convertedcurrencycode: (self.bookingResultModel?.convertedcurrencycode ?? ""))
        pageObj.stripeKey = (self.bookingResultModel?.stripePublishkey ?? "")
        pageObj.doctor_id = (self.bookingResultModel?.doctorId ?? "")
        pageObj.booking_id = (self.bookingResultModel?.bookingId ?? "")
        self.navigationController?.pushViewController(pageObj, animated: true)
    }
    
    func attemptCall(with type: CallConferenceType) {
    
        //here start code flow
       // oppoennets

        //let someString = "5801837" //mailto:notify@mailinator.com iphone6 oppent doctor oda opponent
        
       // let someString = "5801596" //mailto:goolawyer@mailinator.com iphone7+   user oda opponent
        
        if (UserDefaultModule.shared.getLoginData().type ?? "").lowercased() == "doctor"{
            self.somestring = self.bookingResultModel?.ownuser_connectycube_userid ?? ""  //opponent of doctor
            print("somestring ======= \(somestring)")
        }else{
            self.somestring = self.bookingResultModel?.connectycube_userid ?? ""  //opponent of user
        }
        
//        if self.type.lowercased() == "user" {
//            let callModel = CallViewModel()
//            callModel.intimatecall(user_id: (UserDefaultModule.shared.getLoginData().userId ?? ""), booking_id: (self.bookingResultModel?.bookingId ?? "")) { (success) in
//                Utility.shared.stopAnimation(viewController: self)
//
//                let alert = UIAlertController(title: nil, message: "Initimation sent to your lawyer,Please,wait for your lawyer's call", preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: getLanguage["OK"] ?? "", style: .cancel, handler: nil))
//                self.present(alert, animated: true, completion: nil)
//
//            } onFailure: { (failure) in
//                Utility.shared.stopAnimation(viewController: self)
//            }
//
//
//        }else if self.type.lowercased() == "digitalclinic" {
//            let callModel = CallViewModel()
//            callModel.intimatecall(user_id: (UserDefaultModule.shared.getLoginData().userId ?? ""), booking_id: (self.bookingResultModel?.bookingId ?? "")) { (success) in
//                Utility.shared.stopAnimation(viewController: self)
//
//                let alert = UIAlertController(title: nil, message: "Initimation sent to your lawyer,Please,wait for your lawyer's call", preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: getLanguage["OK"] ?? "", style: .cancel, handler: nil))
//                self.present(alert, animated: true, completion: nil)
//
//            } onFailure: { (failure) in
//                Utility.shared.stopAnimation(viewController: self)
//            }
//
//
//        }else{
            
         
            
            if let myInteger = Int(self.somestring)
            {
                self.myNumber = NSNumber(value:myInteger)
                print(myNumber)
            }
            else
            {
                print("'\(self.somestring)' did not convert to an Int")
            }
            
            var opponentIDs: [NSNumber] = []
            opponentIDs.append(self.myNumber)
            
            if let session = CallClient.instance().createNewSession(withOpponents: opponentIDs, with: type) as CallSession?
            {
                self.session = session
                self.callUUID = UUID()
                
                CallKitAdapter.shared.startCall(with: opponentIDs as! [Int], session: session, uuid: self.callUUID!)
                
                /*
                  //old
                let payload =
                [
                    "message" : String(format: "%@ is calling you.", Profile.currentProfile!.fullName!),
                    "ios_voip" : "1",
                    kVOIPEvent : "1",
                    
                ]
                */
                
                /*
                 //sample
                let event = Event()
                event.notificationType = .push
                event.usersIDs = opponentIDs
                event.type = .oneShot

                var pushParameters = [String : String]()
         
                pushParameters["message"] = "Bitcoin trends"
                pushParameters["ios_badge"] = "2"
                pushParameters["ios_sound"] = "app_sound.wav"

                // custom params
                pushParameters["thread_likes"] = "24"
                pushParameters["thread_id"] = "678923"

                if let jsonData = try? JSONSerialization.data(withJSONObject: pushParameters,
                                                            options: .prettyPrinted) {
                  let jsonString = String(bytes: jsonData,
                                          encoding: String.Encoding.utf8)

                  event.message = jsonString

                  Request.createEvent(event, successBlock: {(events) in

                  }, errorBlock: {(error) in

                  })
                }
        */
        /*
                let data = try! JSONSerialization.data(withJSONObject: payload, options: .prettyPrinted)
                let message = String(data: data, encoding: String.Encoding.utf8)
                let event = Event()

                event.notificationType = .push
                event.usersIDs = opponentIDs
                event.type = .oneShot
                event.message = message

                Request.createEvent(event, successBlock: { (event) in
                    NSLog("Send voip push - Success")
                }) { (error) in
                    NSLog("Send voip push - Error")
                    print("Send voip push error:\(error.localizedDescription)")
                }
            */
                
                let callVC =  CallViewController1()

                    callVC.call_type = "video"
                    callVC.receiverId =  self.bookingResultModel?.userId ?? ""
//                    callVC.receiverId =  self.bookingResultModel?.client_id ?? ""
                    callVC.userType = self.type.lowercased()
                    callVC.chatData = self.bookingResultModel
                    callVC.session = self.session
                    callVC.callUUID = self.callUUID
                    self.appDelegate.callUUID = self.callUUID
                    self.appDelegate.session = self.session
                    callVC.modalPresentationStyle = .fullScreen
                    self.appDelegate.window?.rootViewController?.present(callVC, animated: true, completion: nil)

                    //self.performSegue(withIdentifier: Segues.callSceneID, sender: self.callUUID)
                  
       
                
            }
            else
            {
                print("not working")
            }
            
            
            
            
        }
    
    @IBAction func videoVisitButtonAct(_ sender: UIButton) {
        if self.testing == "connect"
        {
            if sender.alpha == 1{
                Utility.shared.startAnimation(viewController: self)
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                Utility.shared.stopAnimation(viewController: self)
                self.attemptCall(with: .video)
                }
                    
            }
        }
        else
        {
            /*
            if sender.alpha == 1 {
                let pageobj = CallViewController()
                if type.lowercased() != "doctor" {
                    pageobj.call_type = "request"
                    pageobj.receiverId =  (self.bookingResultModel?.doctorId ?? "")
                    pageobj.userType = type.lowercased()
                    pageobj.chatData = self.bookingResultModel
                    pageobj.senderFlag = true
                    pageobj.modalPresentationStyle = .fullScreen
                }
                else {
                    pageobj.call_type = "call"
                    pageobj.receiverId =  self.bookingResultModel?.userId ?? ""
                    pageobj.userType = type.lowercased()
                    //            pageobj.random_id = random_id
                    pageobj.chatData = self.bookingResultModel
                    Utility.shared.startAnimation(viewController: self)
                    
                }
                let callModel = CallViewModel()
                callModel.checkChat(sender_id: (UserDefaultModule.shared.getLoginData().userId ?? ""), chat_id: self.booking_id) { (success) in
                    
                    if (callModel.statusModel?.status ?? false) && (callModel.statusModel?.call_status ?? "") == "create"{
                        pageobj.senderFlag = true
                    }
                    else {
                        pageobj.senderFlag = false
                        pageobj.viewType = "2"
                    }
                    pageobj.room_id = (callModel.statusModel?.room_id ?? "")
                    pageobj.modalPresentationStyle = .fullScreen
                    if (callModel.statusModel?.status ?? false) {
                        self.appDelegate.window?.rootViewController?.present(pageobj, animated: true, completion: nil)
                    }
                    else {
                        let alert = UIAlertController(title: nil, message: getLanguage[(callModel.statusModel?.message ?? "")] ?? (callModel.statusModel?.message ?? ""), preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: getLanguage["OK"] ?? "OK", style: .cancel, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    Utility.shared.stopAnimation(viewController: self)
                } onFailure: { (failure) in
                    Utility.shared.stopAnimation(viewController: self)
                }
            }
            else {
                let alert = UIAlertController(title: nil, message: getLanguage["Your Video Call timing is not matched with your booking time. kindly wait  till  your booked timing slot."] ?? "Your Video Call timing is not matched with your booking time. kindly wait  till  your booked timing slot.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: getLanguage["OK"] ?? "", style: .cancel, handler: { (UIAlertAction) in
                }))
                self.present(alert, animated: true, completion: nil)
            }*/
        }
    }
    @IBAction func declineButtonAct(_ sender: UIButton) {
        Utility.shared.startAnimation(viewController: self)
        var cancelStatus = "cancelled"
        if getLanguage[(sender.currentTitle ?? "")] == getLanguage["decline"]  {
            cancelStatus = "declined"
        }
        self.viewModel.CancelBooking(user_id: (UserDefaultModule.shared.getLoginData().userId ?? ""), type: self.type, booking_id: (self.bookingResultModel?.bookingId ?? ""), status: cancelStatus, onSuccess: { (success) in
            Utility.shared.stopAnimation(viewController: self)
            let alert = UIAlertController(title: nil, message: getLanguage[(self.viewModel.actionModel?.message ?? "")] ?? (self.viewModel.actionModel?.message ?? ""), preferredStyle: .alert)
            if success {
                alert.message = getLanguage[(self.viewModel.actionModel?.message ?? "")] ?? (self.viewModel.actionModel?.message ?? "")
            }
            alert.addAction(UIAlertAction(title: getLanguage["OK"] ?? "", style: .cancel, handler: { (UIAlertAction) in
                if success {
                    self.bookingResultModel?.status = "cancelled"
                    self.loadUserData()
                }
            }))
            self.present(alert, animated: true, completion: nil)
        }) { (failure) in
            Utility.shared.stopAnimation(viewController: self)
        }
    }
    @IBAction func prescriptionButtonAct(_ sender: UIButton) {
        if self.type == "doctor"{
            self.prescriptionView.isHidden = false
        }else{
            let pageObj = PrescriptionViewController()
            pageObj.booking_id = self.bookingResultModel?.bookingId ?? ""
            self.navigationController?.pushViewController(pageObj, animated: true)
        }
    }
}

